package com.example.myscanner;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageOptions;
import com.theartofdev.edmodo.cropper.CropImageView;

public class ScanActivity extends AppCompatActivity {

    ImageView imageView;
    ImageButton btnReset,btnCrop;
    private static final int PERMISSION_CODE=1000;
    Uri imageUri;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        imageView = findViewById(R.id.scanImageView);
        btnReset  = findViewById(R.id.btnReset);
        btnCrop   = findViewById(R.id.btnCrop);

        imageUri  = getIntent().getData();
        imageView.setImageURI(imageUri);

        CropImage.activity(imageUri).setGuidelines(CropImageView.Guidelines.ON).setFixAspectRatio(true).setCropMenuCropButtonTitle("Done").setMultiTouchEnabled(true).start(this);

    }

}