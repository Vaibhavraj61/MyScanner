package com.example.myscanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    public static final String RECORD_TABLE="RECORD";
    public static final String RECORD_ID="RECORD_ID";
    public static final String RECORD_DATE="RECORD_DATE";
    public static final String RECORD_TITLE="RECORD_TITLE";
    public static final String RECORD_AMOUNT="RECORD_AMOUNT";

    SQLiteDatabase db =this.getReadableDatabase();
    public DbHelper(@Nullable Context context) {
        super(context, "Expenditure.db",null,1);
    }

    public DbHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "Expenditure.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //sqLiteDatabase = this.getReadableDatabase();
        String sql = "create table "+ RECORD_TABLE +"("+RECORD_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+RECORD_DATE+" TEXT, "+RECORD_TITLE+" TEXT, "+RECORD_AMOUNT+" TEXT)";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+RECORD_TABLE+"");
        onCreate(sqLiteDatabase);
    }

    /*public boolean addRecord(RecordDetails record)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(RECORD_DATE,record.getDate());
        cv.put(RECORD_TITLE,record.getTitle());
        cv.put(RECORD_AMOUNT,record.getAmount());

        long insert = db.insert(RECORD_TABLE,null,cv);
        if(insert==-1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public List<RecordDetails> getRecord()
    {
        List<RecordDetails> returnList = new ArrayList<>();
        String sql ="SELECT * FROM "+RECORD_TABLE;

        Cursor cursor =db.rawQuery(sql,null);

        if(cursor.moveToFirst())
        {
            do{
                String RecordDate =cursor.getString(1);
                String RecordTitle =cursor.getString(2);
                String RecordAmount =cursor.getString(3);

                RecordDetails newStudent = new RecordDetails(RecordDate,RecordTitle,RecordAmount);
                returnList.add(newStudent);

            }while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return returnList;
    }

    public List<RecordDetails> getDates()
    {
        List<RecordDetails> returnList = new ArrayList<>();
        String sql ="SELECT RECORD_DATE FROM "+RECORD_TABLE;

        Cursor cursor =db.rawQuery(sql,null);

        if(cursor.moveToFirst())
        {
            do{
                String RecordDate =cursor.getString(1);

                RecordDetails newStudent = new RecordDetails(RecordDate);
                returnList.add(newStudent);

            }while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return returnList;
    }


    public boolean deleteRecord(String value)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+RECORD_TABLE+" where RECORD_DATE=? ",new String[]{value});
        if(cursor.getCount()>0)
        {
            long result = db.delete(RECORD_TABLE+"","RECORD_DATE=?",new String[]{value});
            if(result == -1)
            {
                return false;
            }
            else{
                return true;
            }
        }
        else {
            return false;
        }*/
    }
