package com.example.myscanner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ContactUsActivity extends AppCompatActivity {

    TextView tv1,tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        tv1 = findViewById(R.id.no1);
        tv2 = findViewById(R.id.no2);

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:"+tv1.getText()));
                startActivity(intent);
            }
        });

        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:"+tv2.getText()));
                startActivity(intent);
            }
        });
    }

    @Override
    // for menu bar in application
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = new MenuInflater(ContactUsActivity.this);
        inflater.inflate(R.menu.nav_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.home) {
            startActivity(new Intent(ContactUsActivity.this, HomeActivity.class));
        }
        if (item.getItemId() == R.id.contact) {
            Toast.makeText(ContactUsActivity.this,"Current",Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.about) {
            startActivity(new Intent(ContactUsActivity.this, AboutActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

}